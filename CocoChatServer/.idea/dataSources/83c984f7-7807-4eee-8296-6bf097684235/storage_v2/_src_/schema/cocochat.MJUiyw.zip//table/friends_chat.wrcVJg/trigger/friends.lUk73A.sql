create trigger friends
  before UPDATE
  on friends_chat
  for each row
  if new.Filter_Type = 'Amigos' && old.Filter_Type = 'Solicitud'
      then
        set new.Msg_Time=now();
  end if;

